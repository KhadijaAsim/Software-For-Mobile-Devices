package com.example.machine.assignment2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Signup_Constraint extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup__constraint);
        final EditText email = (EditText)findViewById(R.id.editText3);
        final EditText password = (EditText)findViewById(R.id.editText4);
        Button Register = (Button) findViewById(R.id.button3);
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                final String Get_email = email.getText().toString();
                final String Get_password = password.getText().toString();
                boolean isChecked = ((CheckBox) findViewById(R.id.checkBox2)).isChecked();
                final RadioGroup Gender = (RadioGroup)findViewById(R.id.radioGroup);
                final RadioButton radioButton_gender;
                int selectedId = Gender.getCheckedRadioButtonId();
                RadioButton radioSexButton = (RadioButton) findViewById(selectedId);
                String value = radioSexButton.getText().toString();
                radioButton_gender =(RadioButton) findViewById(selectedId);

                if(isChecked == true)
                {
                    Toast.makeText(getApplicationContext(), "Email: "+ Get_email + "\n" + "Password: " + Get_password + "\n" +"Gender: " + value + "\n" + "Terms and Condition Status: " + "Checked" ,  Toast.LENGTH_LONG).show();
                }

                else if (isChecked == false)
                {
                    Toast.makeText(getApplicationContext(), "Please accept the terms and conditions to continue", Toast.LENGTH_LONG).show();
                }
            }
        });
        }
}
